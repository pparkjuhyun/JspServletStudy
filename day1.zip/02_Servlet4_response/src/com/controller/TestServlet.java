package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. MIME TYPE 지정: client에게 처리할 데이터 종류 및 인코딩 설정
		response.setContentType("text/html;charset=utf-8");
		
		//2. Java I/O
		PrintWriter out = response.getWriter();

		//3. write html
		out.print("<html>\n<body>\nHello World 박주현</body>\n</html>");
	}
}

