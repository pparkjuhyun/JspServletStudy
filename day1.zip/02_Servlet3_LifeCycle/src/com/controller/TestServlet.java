package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int num=0;
	ArrayList<String> list = new ArrayList<>();
	
	
	@Override
	public void destroy() {
		System.out.println("destroy");
	}



	@Override
	public void init() throws ServletException {
		System.out.println("init");
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int size = 10;
		num++;
		size++;
		list.add("parkjuhyun");
		System.out.println("TestServlet.doGet" + num);
		System.out.println("TestServlet.doGet" + list.toString());
		System.out.println("TestServlet.doGet" + size);
	}

}
