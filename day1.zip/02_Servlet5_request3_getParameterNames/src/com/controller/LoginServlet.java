package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("LoginServlet.doGet");
		
		//1. String userid = request.getParameter(name)
		//2. String[] hobbies = request.getParameterValues(name)
		//3.
		Enumeration<String> names = request.getParameterNames();
		while(names.hasMoreElements()) {
			String nameString = names.nextElement();
			String valueString = request.getParameter(nameString);
			System.out.println(nameString + ": " + valueString);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("LoginServlet.doPost");
		
		req.setCharacterEncoding("utf-8");
		doGet(req, resp);
	}
	
	
}
