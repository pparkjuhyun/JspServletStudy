package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ReserveTicketServlet
 */
@WebServlet("/reserveTicket")
public class ReserveTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String birth = request.getParameter("birthday");
		int charge = Integer.parseInt(request.getParameter("type"));
		
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int input = Integer.parseInt(birth.substring(0, 4));
		int diff = year - input;
		
		if(diff <= 9) {
			charge = (int) (charge * 0.6);
		}else if(diff >= 60) {
			charge = (int) (charge * 0.5);
		} else {
			charge = (int) (charge * 0.9);
		}
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		out.print("<html><body>");
		out.print("최종금액: " + charge);
		out.print("</html></body>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
